from pyabsa import APCCheckpointManager, ABSADatasetList

examples = [
    'I have had my computer for 2 weeks already and it [ASP]works[ASP] perfectly . !sent! Positive',
    'And I may be the only one but I am really liking [ASP]Windows 8[ASP] . !sent! Positive',
    '[ASP]Deutsche Bank[ASP] is one of the greatest finance instituations around the globe',
    'I really dislike the new feature of [ASP]Deutsche Bank[ASP]',
    '[ASP]HSBC[ASP] is a bad company',
    ' if you ask me, I would say that [ASP]Deutsche Bank is[ASP] not complying and a [ASP]honorable bank[ASP]',
    '[ASP]Unilever[ASP] is a great company as just recently [ASP]launched[ASP] its IPO on the [ASP]Deutsche Boerse[ASP]',
    'The 150-year-old [ASP]Deutsche Bank AG (DB)[ASP] announced on Sunday a much-awaited radical [ASP]transformation[ASP] that the embattled company hopes will make it leaner and meaner and able to survive in the long term'
]

examples = ['I have had my [ASP]computer[ASP] for 2 weeks already and it [ASP]works[ASP] perfectly .']


sent_classifier = APCCheckpointManager.get_sentiment_classifier(checkpoint='english', auto_device=True)

for ex in examples:
  print("---------------------------------------------------")
  result = sent_classifier.infer(ex, print_result=True)
  print(result)



