##############################
# import of relevant modules #
##############################
import gc
import os
import numpy as np
import pandas as pd
import tqdm
import pickle
import gc

from pyabsa import APCCheckpointManager
from flair.models import SequenceTagger
from flair.tokenization import SegtokSentenceSplitter
from ABSA_Evaluation_HelperFunctions import APC_NER_Prediction
from tqdm import tqdm
from datetime import datetime



#####################
# APC model loading #
#####################
def load_apc_model(model_name):
    sent_classifier = APCCheckpointManager.get_sentiment_classifier(checkpoint=model_name,
                                                                    auto_device=True)
    return sent_classifier


#####################
# NER model loading #
#####################
def load_ner_model(ner_model_name):

    tagger = SequenceTagger.load(ner_model_name)
    splitter = SegtokSentenceSplitter()

    return tagger, splitter


#####################
# E2E ABSA Pipeline #
#####################
def e2e_absa_pipeline(predictor):
    """
            function to orchestrate the whole pipeline
            1. apply NER on input text (sentence splitting, NER, APC formatting, ...)
            2. apply APC on preprocessed sentences
            3. concat NER and APC results for each sentence in one df
            4. format each sentence within the df into succeeding html/markdown embedding in the app
            :input: raw text
            :output: df with final format of sentences for latter html/markdown embedding
            """

    # initialize the assembler object that orchestrates in the following way
    # text input --> apply NER --> apply ABSA --> result formatting
    predictor.assembler()
    return predictor.ner_apc_df


##################################
# Sentiment Aggregation Function #
##################################
def sentiment_aggregation(x):
    tmp = pd.DataFrame(x)
    tmp = tmp.explode(['aspect', 'sentiment', 'confidence'])
    tmp = tmp[tmp.aspect != 'N.A.']
    if tmp.shape[0] > 0:
        tmp['sent_polarity'] = tmp.sentiment.apply(lambda z: -1 if z == 'Negative' else 1)
        tmp['confidence'] = tmp.apply(lambda y: y['confidence'] * y['sent_polarity'], axis=1)

        tmpt = pd.DataFrame()
        for ix, i in tmp.groupby('aspect'):
            # assign weighting function
            conf_avg = np.mean(i.confidence.to_list())
            if (conf_avg < 0.3) & (conf_avg > -0.3):
                # neutral sentiment
                sentiment = 0
            elif conf_avg > 0.3:
                # positive sentiment
                sentiment = 1
            else:
                # negative sentiment
                sentiment = -1
            i['sentiment_class'] = sentiment
            i['conv_avg'] = conf_avg
            i = i.head(1)[['aspect', 'sentiment_class', 'conv_avg']]
            i = i.reset_index(drop=True)
            tmpt = tmpt.reset_index(drop=True)
            tmpt = pd.concat([i, tmpt], axis=0)

        return tmpt.to_dict()

    else:
        return "drop row"

########################################
# exact prediction matching evaluation #
########################################
def prediction_eval_exact(x):
    eval_dict = {}
    for asp in x.aggregated_sentiment['aspect']:
        asp_name = x.aggregated_sentiment['aspect'][asp]

        for asset in x.analytics:
            asset_name = x.analytics[asset]['assetName']

            # do exakt matching - no fuzzy matching like 'contains', 'thresholds', 'similarity measures'
            if asp_name.lower() == asset_name.lower():
                # keep only thos analytics entries that have a match with our ner predictions
                eval_dict[asp_name] = {'annotation_name': asset_name,
                                       'prediction_name': asp_name,
                                       'annotation_class': x.analytics[asset]['sentimentClass'],
                                       'prediction_class': x.aggregated_sentiment['sentiment_class'][asp]}

    return eval_dict

########################################
# fuzzy prediction matching evaluation #
########################################
def prediction_eval_fuzzy(x):
    eval_dict = {}
    for asp in x.aggregated_sentiment['aspect']:
        asp_name = x.aggregated_sentiment['aspect'][asp]

        for asset in x.analytics:
            asset_name = x.analytics[asset]['assetName']

            # do exakt matching - no fuzzy matching like 'contains', 'thresholds', 'similarity measures'
            if asp_name.lower() in asset_name.lower():
                # keep only thos analytics entries that have a match with our ner predictions
                eval_dict[asp_name] = {'annotation_name': asset_name,
                                       'prediction_name': asp_name,
                                       'annotation_class': x.analytics[asset]['sentimentClass'],
                                       'prediction_class': x.aggregated_sentiment['sentiment_class'][asp]}

    return eval_dict

#################################
# evaluation metric calculation #
#################################
def q_metric(x, prediction_eval):
    q_metrics = {}

    if len(x[prediction_eval]) == 0:
        q_metrics['result'] = 'nothing_found'
    else:
        for eval_elem in x[prediction_eval]:
            if (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'true positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'false neutral'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'false negative'

            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'true neutral'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'false positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'false negative'

            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'true negative'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'false positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'false neutral'

            else:
                q_metrics[eval_elem] = 'uncovered_case'

    return q_metrics


##################################
# evaluation metric accumulation #
##################################
def metric_counter(x, eval_dict, match_type):
    for key in x[match_type].keys():
        eval_dict[x[match_type][key]] += 1

    return eval_dict


if __name__ == "__main__":
    # load sentiment classifier model
    sent_classifier = load_apc_model('english')

    # load ner model
    ner_model_name = "flair/ner-english-large"
    tagger, splitter = load_ner_model(ner_model_name)

    # create the object APC object for APC inference
    predictor = APC_NER_Prediction()

    # initialize the relevant NER functions for text processing
    predictor.tagger = tagger
    predictor.splitter = splitter

    # initialize the APC classifier (sentiment)
    predictor.sent_classifier = sent_classifier

    # initialize the entity that should be referenced for sentiment predictions
    entity = "ORG"
    predictor.entity = entity

    # define base directory that contains the refinitiv data
    base_dir = "../refinitv_data_json_mod"

    # iterativly go through the base directory, extract the refinitiv samples,
    # infer the sentiment and calculat the performance

    final_result = {}
    for file in tqdm(os.listdir(base_dir)):
        try:
            print("read refinitiv data file")
            input_text_df = pd.read_json(os.path.join(os.getcwd(), base_dir + '/' + file), orient='records')
            # comment out for debugging purposes
            # input_text_df = input_text_df.head(500

            print('create one text corpus and drop not required columns')
            # create one column that comprises all inference relevant text
            input_text_df['text'] = input_text_df.apply(lambda x: x[0] + ". " + x[1], axis=1)
            input_text_df = input_text_df[['text', 'analytics']]

            # apply NER
            print('applying ner')
            input_text_df['ner_result'] = input_text_df.text.apply(lambda x: predictor.ner_detection(x))

            # infer the sentiment on the predicted entities
            print('applying the apc module')
            input_text_df['apc_result'] = input_text_df.ner_result.apply(lambda x: predictor.apc(x))
            # save interim result and override it once next step is completed
            input_text_df.to_json(
                os.path.join('../prediction_evaluations', f"ABSA_Prediction_{file}_2022-09-07.json"),
                orient='records')

            # aggregate sentiment over for each entity via polarity score averaging
            print(f'aggregating sentiment / shape of df till here: {input_text_df.shape}')
            input_text_df['aggregated_sentiment'] = input_text_df.apc_result.apply(lambda x: sentiment_aggregation(x))
            # drop all rows in df that comprise input_text_df[input_text_df['aggregated_sentiment'] != 'drop row']
            input_text_df = input_text_df[input_text_df['aggregated_sentiment'] != 'drop row']
            print(f'aggregated sentiment and dropped instances without any aspect: {input_text_df.shape}')

            # persist intermediate result
            input_text_df.to_json(
                os.path.join('../prediction_evaluations', f"ABSA_Prediction_{file}_2022-09-07.json"),
                orient='records')

            # match (exact and fuzzy) model predictions with refinitiv annotations
            print('performing evaluation')
            input_text_df['prediction_eval_exact'] = input_text_df.apply(lambda x: prediction_eval_exact(x), axis=1)
            input_text_df['prediction_eval_fuzzy'] = input_text_df.apply(lambda x: prediction_eval_fuzzy(x), axis=1)
            # calculate model performance on exact and fuzzy matched
            input_text_df['metric_exact_match'] = input_text_df.apply(lambda x: q_metric(x, 'prediction_eval_exact'), axis=1)
            input_text_df['metric_fuzzy_match'] = input_text_df.apply(lambda x: q_metric(x, 'prediction_eval_fuzzy'), axis=1)

            # final evaluation of the models prediction on refinitiv data (counts of tp, fn, fp, ...)
            # -- exact matches --
            eval_dict_exm = {"nothing_found": 0,
                             "false positive": 0,
                             "false negative": 0,
                             "true positive": 0,
                             "true negative": 0,
                             "true neutral": 0,
                             "false neutral": 0}
            match_type = 'metric_exact_match'
            result_exm = input_text_df.apply(lambda x: metric_counter(x, eval_dict_exm, match_type), axis=1)
            result_exm = result_exm.head(1).to_dict()[0]
            # -- fuzzy matches --
            eval_dict_fum = {"nothing_found": 0,
                             "false positive": 0,
                             "false negative": 0,
                             "true positive": 0,
                             "true negative": 0,
                             "true neutral": 0,
                             "false neutral": 0}
            match_type = 'metric_fuzzy_match'
            result_fum = input_text_df.apply(lambda x: metric_counter(x, eval_dict_fum, match_type), axis=1)
            result_fum = result_fum.head(1).to_dict()[0]

            # save predictions and evaluation metrics to dedicated json file - corresponding to input file
            # persist final result and override old file
            input_text_df.to_json(
                os.path.join('../prediction_evaluations', f"ABSA_Prediction_{file}_2022-09-07.json"),
                orient='records')

            print("#####################################################################################################")
            print(f"## Evaluation result for exact matches on: {file} ##")
            print(result_exm)
            print("#####################################################################################################")
            print(f"## Evaluation result for fuzzy matches on: {file} ##")
            print(result_fum)
            print("#####################################################################################################")
            print(" ")
            print(" ")
            final_result[f"exact_match_{file}"] = result_exm
            final_result[f"fuzzy_match_{file}"] = result_fum

        except Exception as e:
            print("#################################################")
            print(f"Error occured within this file: {file}")
            print(e)
            print("#################################################")
            print(" ")
            print(" ")
            final_result[file] = "error occurred"

        gc.collect()

        with open('final_result_ref_eval_2022-09-08.pickle', 'wb') as handle:
            pickle.dump(final_result, handle, protocol=pickle.HIGHEST_PROTOCOL)

