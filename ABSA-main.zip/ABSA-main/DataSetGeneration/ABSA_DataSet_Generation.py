##############################
# import of relevant modules #
##############################
import gc
import os
import numpy as np
import pandas as pd


import ast
from pyabsa import APCCheckpointManager
from flair.models import SequenceTagger
from flair.tokenization import SegtokSentenceSplitter
from ABSA_Evaluation_HelperFunctions import APC_NER_Prediction



#####################
# APC model loading #
#####################
def load_apc_model(model_name):
    sent_classifier = APCCheckpointManager.get_sentiment_classifier(checkpoint=model_name,
                                                                    auto_device=True)
    return sent_classifier


#####################
# NER model loading #
#####################
def load_ner_model(ner_model_name):

    tagger = SequenceTagger.load(ner_model_name)
    splitter = SegtokSentenceSplitter()

    return tagger, splitter


#####################
# E2E ABSA Pipeline #
#####################
def e2e_absa_pipeline(predictor):
    """
            function to orchestrate the whole pipeline
            1. apply NER on input text (sentence splitting, NER, APC formatting, ...)
            2. apply APC on preprocessed sentences
            3. concat NER and APC results for each sentence in one df
            4. format each sentence within the df into succeeding html/markdown embedding in the app
            :input: raw text
            :output: df with final format of sentences for latter html/markdown embedding
            """

    # initialize the assembler object that orchestrates in the following way
    # text input --> apply NER --> apply ABSA --> result formatting
    predictor.assembler()
    return predictor.ner_apc_df


##################################
# Sentiment Aggregation Function #
##################################
def sentiment_aggregation(x):
    tmp = pd.DataFrame(x)
    tmp = tmp.explode(['aspect', 'sentiment', 'confidence'])
    tmp = tmp[tmp.aspect != 'N.A.']
    tmp['sent_polarity'] = tmp.sentiment.apply(lambda x: -1 if x == 'Negative' else 1)
    tmp['confidence'] = tmp.apply(lambda x: x[3] * x[-1], axis=1)

    tmpt = pd.DataFrame()
    for ix, i in tmp.groupby('aspect'):
        # assign weighting function
        conf_avg = np.mean(i.confidence.to_list())
        if (conf_avg < 0.3) & (conf_avg > -0.3):
            # neutral sentiment
            sentiment = 0
        elif conf_avg > 0.3:
            # positive sentiment
            sentiment = 1
        else:
            # negative sentiment
            sentiment = -1
        i['sentiment_class'] = sentiment
        i['conv_avg'] = conf_avg
        i = i.head(1)[['aspect', 'sentiment_class', 'conv_avg']]
        i = i.reset_index(drop=True)
        tmpt = tmpt.reset_index(drop=True)
        tmpt = pd.concat([i, tmpt], axis=0)

    return tmpt.to_dict()

########################################
# exact prediction matching evaluation #
########################################
def prediction_eval_exact(x):
    eval_dict = {}
    for asp in x.aggregated_sentiment['aspect']:
        asp_name = x.aggregated_sentiment['aspect'][asp]

        for asset in x.analytics:
            asset_name = x.analytics[asset]['assetName']

            # do exakt matching - no fuzzy matching like 'contains', 'thresholds', 'similarity measures'
            if asp_name.lower() == asset_name.lower():
                # keep only thos analytics entries that have a match with our ner predictions
                eval_dict[asp_name] = {'annotation_name': asset_name,
                                       'prediction_name': asp_name,
                                       'annotation_class': x.analytics[asset]['sentimentClass'],
                                       'prediction_class': x.aggregated_sentiment['sentiment_class'][asp]}

    return eval_dict

########################################
# fuzzy prediction matching evaluation #
########################################
def prediction_eval_fuzzy(x):
    eval_dict = {}
    for asp in x.aggregated_sentiment['aspect']:
        asp_name = x.aggregated_sentiment['aspect'][asp]

        for asset in x.analytics:
            asset_name = x.analytics[asset]['assetName']

            # do exakt matching - no fuzzy matching like 'contains', 'thresholds', 'similarity measures'
            if asp_name.lower() in asset_name.lower():
                # keep only thos analytics entries that have a match with our ner predictions
                eval_dict[asp_name] = {'annotation_name': asset_name,
                                       'prediction_name': asp_name,
                                       'annotation_class': x.analytics[asset]['sentimentClass'],
                                       'prediction_class': x.aggregated_sentiment['sentiment_class'][asp]}

    return eval_dict

#################################
# evaluation metric calculation #
#################################
def q_metric(x, prediction_eval):
    q_metrics = {}

    if len(x[prediction_eval]) == 0:
        q_metrics['result'] = 'nothing_found'
    else:
        for eval_elem in x[prediction_eval]:
            if (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'true positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'false neutral'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 1) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'false negative'

            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'true neutral'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'false positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == 0) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'false negative'

            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == -1):
                q_metrics[eval_elem] = 'true negative'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == 1):
                q_metrics[eval_elem] = 'false positive'
            elif (x[prediction_eval][eval_elem]["annotation_class"] == -1) & (x[prediction_eval][eval_elem]["prediction_class"] == 0):
                q_metrics[eval_elem] = 'false neutral'

            else:
                q_metrics[eval_elem] = 'uncovered_case'

    return q_metrics


##################################
# evaluation metric accumulation #
##################################
def metric_counter(x, eval_dict, match_type):
    for key in x[match_type].keys():
        eval_dict[x[match_type][key]] += 1

    return eval_dict

def annotater(x):
    annot_dict = {}
    # get asset name and check how often it occurs in the text
    for i in x.analytics:
        if x.analytics[i]['assetClass'] == 'CMPNY':
            assetName = x.analytics[i]['assetName']
            # print(assetName)

            # make it as a data frame
            tmp = pd.DataFrame(x.apc_result).explode(['aspect', 'sentiment', 'confidence'])
            tmp = tmp[tmp.aspect != 'N.A.']

            # filter for the assetName in the dataframe
            tmp['aspect'] = tmp.aspect.apply(lambda x: x.lower())
            tmp = tmp[tmp.aspect == assetName.lower()]
            if tmp.shape[0] == 0:
                annot_dict[i] = 'N.A.'

            else:
                # join with df of ner_results where the assetName equals
                tmp_ner = x.ner_result
                tmp_ner = tmp_ner.explode(['span', 'ents', 'name', ])
                tmp_ner['name'] = tmp_ner.name.apply(lambda x: x.lower())
                tmp_ner = tmp_ner[tmp_ner.name == assetName.lower()]

                joined_df = tmp.merge(tmp_ner, left_on='aspect', right_on='name')

                # add the analytics sentiment to it
                # create a dataframe for the analytics annotation
                tmp_analytics = pd.DataFrame(x.analytics).T
                tmp_analytics['assetName'] = tmp_analytics.assetName.apply(lambda x: x.lower())
                joined_df = joined_df.merge(tmp_analytics, left_on='aspect', right_on='assetName')

                joined_df = joined_df[['text',
                                       'aspect',
                                       'sentiment',
                                       'confidence',
                                       'probs',
                                       'span',
                                       'ents',
                                       'name',
                                       'sent',
                                       'assetClass',
                                       'assetName',
                                       'firstMentionSentence',
                                       'sentimentClass',
                                       'sentimentNegative',
                                       'sentimentNeutral',
                                       'sentimentPositive',
                                       'sentimentWordCount']]


                annot_dict[i] = joined_df.to_json()

        else:
            annot_dict[i] = 'N.A.'

    if 'N.A.' in annot_dict.values():
        return 'drop'
    else:
        return annot_dict


def sentiment_mapper(x):
    if x == 'Neutral':
        r = 0
    elif x == 'Negative':
        r = -1
    else:
        r = 1
    return r


if __name__ == "__main__":
    # load sentiment classifier model
    sent_classifier = load_apc_model('english')

    # load ner model
    ner_model_name = "flair/ner-english-large"
    tagger, splitter = load_ner_model(ner_model_name)

    # create the object APC object for APC inference
    predictor = APC_NER_Prediction()

    # initialize the relevant NER functions for text processing
    predictor.tagger = tagger
    predictor.splitter = splitter

    # initialize the APC classifier (sentiment)
    predictor.sent_classifier = sent_classifier

    # initialize the entity that should be referenced for sentiment predictions
    entity = "ORG"
    predictor.entity = entity

    # define base directory that contains the refinitiv data
    base_dir = "../refinitv_data_json_mod"

    # iterativly go through the base directory, extract the refinitiv samples,
    # infer the sentiment and calculat the performance

    final_result = {}
    for file in os.listdir(base_dir):
        try:
            # read the refinitive sample file
            print('read in Refinitiv data')
            input_text_df = pd.read_json(os.path.join(os.getcwd(), base_dir + '/' + file), orient='records')
            # comment out for debugging purposes
            # input_text_df = input_text_df.head(5)
            print('finished Refinitiv data reading process')

            # create one column that comprises all inference relevant text
            print('create one consecutive text corpus for inference')
            input_text_df['text'] = input_text_df.apply(lambda x: x[0] + ". " + x[1], axis=1)

            print('drop columns that are not required anymore')
            input_text_df = input_text_df[['text', 'analytics']]

            # apply NER
            print('apply NER module to the text')
            input_text_df['ner_result'] = input_text_df.text.apply(lambda x: predictor.ner_detection(x))

            # infer the sentiment on the predicted entities
            print('apply APC module to the text')
            input_text_df['apc_result'] = input_text_df.ner_result.apply(lambda x: predictor.apc(x))

            print('retrieve exact annotation-to-prediction entity matches')
            input_text_df['annotation_data'] = input_text_df.apply(lambda x: annotater(x), axis=1)

            print('save interim result --> later to be replaced by the final result')
            input_text_df.to_json(os.path.join('../annotation_data', f"AnnotationData_{file.replace('.json', '')}_2022-09-08.json"), orient='records')
            # input_text_df.to_excel(os.path.join('prediction_evaluations', f"ABSA_AnnotationData_{file}_2022-09-7_{datetime.now()}.xlsx"))

            print('apply final output formatting and annotation generation process')
            # input_text_df['annotation_data'] = input_text_df.annotation_data.apply(lambda x: str(x))
            input_text_df = input_text_df[input_text_df.annotation_data != "drop"]
            if input_text_df.shape[0] != 0:
                input_text_df['annotation_data'] = input_text_df.annotation_data.apply(lambda x: x if type(x) == dict else ast.literal_eval(x))

                # transform it into a dataset that can be used for annotation
                tmp = pd.DataFrame()
                annotation_df = pd.DataFrame(input_text_df['annotation_data'])
                annotation_df = annotation_df.reset_index(drop=True)

                for ix, i in annotation_df.iterrows():
                    for key in i.annotation_data.keys():
                        if i.annotation_data[key] != 'N.A.':
                            content = ast.literal_eval(i.annotation_data[key])
                            content_df = pd.DataFrame(content)
                            tmp = tmp.reset_index(drop=True)
                            content_df = content_df.reset_index(drop=True)
                            tmp = pd.concat([tmp, content_df])

                tmp = tmp.rename(columns={'text': 'InputText',
                                        'assetName': 'AnnotatedAssetName',
                                        'aspect': 'PredictedAssetName',
                                        'span': 'AspectSpan',
                                        'sentiment': 'PredictedSentiment',
                                        'confidence': 'PredictionConfidence',
                                        'probs': 'PredictionProbabilities',
                                        'sentimentClass': 'AnnotatedSentiment',
                                        'ents': 'PredictedEntity',
                                        'assetClass': 'AnnotatedEntity',
                                        'sent': 'InferenceSentence'})

                tmp['AnnotatedSentimentProbabilities'] = tmp.apply(
                    lambda x: [x['sentimentNegative'], x['sentimentNeutral'], x['sentimentPositive']], axis=1)

                tmp['PredictedSentiment'] = tmp.PredictedSentiment.apply(lambda x: sentiment_mapper(x))

                tmp = tmp[['InputText',
                         'InferenceSentence',
                         'AnnotatedAssetName',
                         'PredictedAssetName',
                         'AspectSpan',
                         'PredictedSentiment',
                         'PredictionConfidence',
                         'PredictionProbabilities',
                         'AnnotatedSentiment',
                         'AnnotatedSentimentProbabilities',
                         'PredictedEntity',
                         'AnnotatedEntity'
                         ]]

                # drop duplicated within the data
                tmp = tmp.drop_duplicates(['InferenceSentence', 'AnnotatedAssetName'])

                tmp.to_json(os.path.join('../annotation_data', f"AnnotationData_{file.replace('.json', '')}_2022-09-08.json"), orient='records')
                print('saved final output and start the processing of a new file')
                print('#--------------------------------------------------------#')

            else:
                print('no matches found --> taking next file')
                print('#--------------------------------------------------------#')

            # clean memory
            gc.collect()

        except Exception as e:
            print("#################################################")
            print(f"Error occured within this file: {file}")
            print(f"Error : {e}")
            print("#################################################")
            print(" ")
            print(" ")

